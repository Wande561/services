import React from 'react';
import { useAuth } from '../contexts/AppContext';

const AuthDebug: React.FC = () => {
  const { identity, isAuthenticated, currentUser, logout } = useAuth();

  const handleClearSession = async () => {
    await logout();
    window.location.reload();
  };

  const handleTestAuth = () => {
    console.log('=== AUTHENTICATION DEBUG ===');
    console.log('User state:', {
      principal: identity?.getPrincipal().toText(),
      isAuthenticated,
      userType: currentUser ? 'registered' : null,
      hasIdentity: !!identity,
      isAnonymous: identity?.getPrincipal().isAnonymous()
    });
    console.log('=== END DEBUG ===');
  };

  return (
    <div className="fixed top-4 right-4 bg-black/80 text-white p-4 rounded-lg text-sm z-50">
      <h3 className="font-bold mb-2">Auth Debug</h3>
      <div className="space-y-1">
        <div>Principal: {identity?.getPrincipal().toText() || 'None'}</div>
        <div>Authenticated: {isAuthenticated ? 'Yes' : 'No'}</div>
        <div>Anonymous: {identity?.getPrincipal().isAnonymous() ? 'Yes' : 'No'}</div>
        <div>User Type: {currentUser ? 'Registered' : 'None'}</div>
        <div>Loading: {isAuthenticated === null ? 'Yes' : 'No'}</div>
      </div>
      <div className="space-y-2 mt-3">
        <button 
          onClick={handleTestAuth}
          className="block w-full bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-xs"
        >
          Log Debug Info
        </button>
        <button 
          onClick={handleClearSession}
          className="block w-full bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-xs"
        >
          Clear Session
        </button>
      </div>
    </div>
  );
};

export default AuthDebug;
