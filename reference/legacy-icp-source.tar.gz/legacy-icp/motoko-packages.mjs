import { execFile } from 'node:child_process';
import { join, relative } from 'node:path';
import { promisify } from 'node:util';

const { stdout } = await promisify(execFile)('dfx', ['cache', 'show']);
const cacheDir = stdout.trim();

for (const name of ['base', 'core']) {
  // The Motoko language server resolves package paths relative to the project.
  const packageDir = relative(process.cwd(), join(cacheDir, name));
  console.log(`--package ${name} ${packageDir}`);
}
