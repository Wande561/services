import CoreList "mo:core/List";

module {
  public class Buffer<T>(_capacity : Nat) {
    let items = CoreList.empty<T>();

    public func add(item : T) {
      CoreList.add(items, item)
    };

    public func size() : Nat {
      CoreList.size(items)
    };

    public func get(index : Nat) : T {
      CoreList.get(items, index)
    };

    public func toArray() : [T] {
      CoreList.toArray(items)
    };
  };

  public func toArray<T>(buffer : Buffer<T>) : [T] {
    buffer.toArray()
  };
}