import CoreMap "mo:core/Map";
import Iter "mo:core/Iter";
import Nat32 "mo:core/Nat32";
import Order "mo:core/Order";

module {
  public class HashMap<K, V>(
    _capacity : Nat,
    _equal : (K, K) -> Bool,
    _hash : K -> Nat32,
    compare : (K, K) -> Order.Order
  ) {
    let data = CoreMap.empty<K, V>();

    public func get(key : K) : ?V {
      CoreMap.get(data, compare, key)
    };

    public func put(key : K, value : V) {
      CoreMap.add(data, compare, key, value)
    };

    public func delete(key : K) {
      CoreMap.remove(data, compare, key)
    };

    public func remove(key : K) : ?V {
      let previous = CoreMap.get(data, compare, key);
      CoreMap.remove(data, compare, key);
      previous
    };

    public func replace(key : K, value : V) : ?V {
      CoreMap.replace(data, compare, key, value)
    };

    public func entries() : Iter.Iter<(K, V)> {
      CoreMap.entries(data)
    };

    public func keys() : Iter.Iter<K> {
      CoreMap.keys(data)
    };

    public func vals() : Iter.Iter<V> {
      CoreMap.values(data)
    };

    public func size() : Nat {
      CoreMap.size(data)
    };
  };

  public func fromIter<K, V>(
    iter : Iter.Iter<(K, V)>,
    _size : Nat,
    _equal : (K, K) -> Bool,
    _hash : K -> Nat32,
    compare : (K, K) -> Order.Order
  ) : HashMap<K, V> {
    let map = HashMap<K, V>(0, _equal, _hash, compare);
    for ((key, value) in iter) {
      map.put(key, value)
    };
    map
  };
}